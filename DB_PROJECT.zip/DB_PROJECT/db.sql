CREATE DATABASE pwb;
USE pwb;
DROP DATABASE pwb;

# CREATION

CREATE TABLE Role (
  role_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(255) NOT NULL
);

CREATE TABLE User (
  user_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  role_id INT NOT NULL,
  FOREIGN KEY (role_id) REFERENCES Role(role_id)
);

CREATE TABLE Project (
  project_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  project_name VARCHAR(255) NOT NULL,
  project_description VARCHAR(255) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  team_lead_id INT NOT NULL,
  FOREIGN KEY (team_lead_id) REFERENCES User(user_id)
);

CREATE TABLE Sprint (
  sprint_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  sprint_name VARCHAR(255) NOT NULL,
  sprint_description VARCHAR(255) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  project_id INT NOT NULL,
  FOREIGN KEY (project_id) REFERENCES Project(project_id)
);

CREATE TABLE Board (
  board_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  board_name VARCHAR(255) NOT NULL,
  board_description VARCHAR(255) NOT NULL,
  project_id INT NOT NULL,
  FOREIGN KEY (project_id) REFERENCES Project(project_id)
);

CREATE TABLE Issue (
  issue_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  issue_type VARCHAR(255) NOT NULL,
  summary VARCHAR(255) NOT NULL,
  issue_description VARCHAR(255) NOT NULL,
  assignee_id INT NOT NULL,
  state VARCHAR(255) NOT NULL,
  priority VARCHAR(255) NOT NULL,
  due_date DATE NOT NULL,
  sprint_id INT NOT NULL,
  board_id INT NOT NULL,
  FOREIGN KEY (assignee_id) REFERENCES User(user_id),
  FOREIGN KEY (sprint_id) REFERENCES Sprint(sprint_id),
  FOREIGN KEY (board_id) REFERENCES Board(board_id)
);

CREATE TABLE Comment (
  comment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  comment_text VARCHAR(255) NOT NULL,
  user_id INT NOT NULL,
  issue_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES User(user_id),
  FOREIGN KEY (issue_id) REFERENCES Issue(issue_id)
);

CREATE TABLE Attachment (
  attachment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  user_id INT NOT NULL,
  issue_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES User(user_id),
  FOREIGN KEY (issue_id) REFERENCES Issue(issue_id)
);

# INSERTION

INSERT INTO role (role_name)
VALUES ('Administrators'), 
	('Project Managers/Team Leads'),
	('Developers/Team Members'),
	('Customers');


INSERT INTO user (user_name, email, password, role_id)
VALUES ('John Smith', 'john.smith@example.com', 'password123', 1),
	('Jane Doe', 'jane.doe@example.com', 'password123', 2),
	('Bob Johnson', 'bob.johnson@example.com', 'password123', 3),
	('Amy Lee', 'amy.lee@example.com', 'password123', 3),
	('Jack White', 'jack.white@example.com', 'password123', 3),
	('Sarah Kim', 'sarah.kim@example.com', 'password123', 4),
	('Tom Brown', 'tom.brown@example.com', 'password123', 4),
	('Emily Davis', 'emily.davis@example.com', 'password123', 4),
	('Oliver Green', 'oliver.green@example.com', 'password123', 4),
	('Hannah Wilson', 'hannah.wilson@example.com', 'password123', 4);


INSERT INTO project (project_name, project_description, start_date, end_date, team_lead_id)
VALUES ('Project 1', 'This is the first project', '2023-05-01', '2023-05-31', 2),
	('Project 2', 'This is the second project', '2023-06-01', '2023-06-30', 2),
	('Project 3', 'This is the third project', '2023-07-01', '2023-07-31', 2),
	('Project 4', 'This is the fourth project', '2023-08-01', '2023-08-31', 2),
	('Project 5', 'This is the fifth project', '2023-09-01', '2023-09-30', 2),
	('Project 6', 'This is the sixth project', '2023-10-01', '2023-10-31', 2),
	('Project 7', 'This is the seventh project', '2023-11-01', '2023-11-30', 2),
	('Project 8', 'This is the eighth project', '2023-12-01', '2023-12-31', 2),
	('Project 9', 'This is the ninth project', '2024-01-01', '2024-01-31', 2),
	('Project 10', 'This is the tenth project', '2024-02-01', '2024-02-29', 2);


    
INSERT INTO Sprint (sprint_name, sprint_description, start_date, end_date, project_id)
VALUES ('Sprint 1', 'First sprint for Project A', '2023-01-01', '2023-01-14', 1),
	('Sprint 2', 'Second sprint for Project A', '2023-01-15', '2023-01-28', 1),
	('Sprint 1', 'First sprint for Project B', '2023-01-01', '2023-01-14', 2),
	('Sprint 2', 'Second sprint for Project B', '2023-01-15', '2023-01-28', 2),
	('Sprint 3', 'Third sprint for Project B', '2023-01-29', '2023-02-11', 2),
	('Sprint 1', 'First sprint for Project C', '2023-01-01', '2023-01-14', 3),
	('Sprint 2', 'Second sprint for Project C', '2023-01-15', '2023-01-28', 3),
	('Sprint 1', 'First sprint for Project D', '2023-01-01', '2023-01-14', 4),
	('Sprint 2', 'Second sprint for Project D', '2023-01-15', '2023-01-28', 4),
	('Sprint 3', 'Third sprint for Project D', '2023-01-29', '2023-02-11', 4);

INSERT INTO Board (board_id, board_name, board_description, project_id)
VALUES (1, 'Design Board', 'Board for design tasks', 1),
	(2, 'Development Board', 'Board for development tasks', 1),
	(3, 'Testing Board', 'Board for testing tasks', 1),
	(4, 'Design Board', 'Board for design tasks', 2),
	(5, 'Development Board', 'Board for development tasks', 2),
	(6, 'Testing Board', 'Board for testing tasks', 2),
	(7, 'Design Board', 'Board for design tasks', 3),
	(8, 'Development Board', 'Board for development tasks', 3),
	(9, 'Testing Board', 'Board for testing tasks', 3),
	(10, 'Design Board', 'Board for design tasks', 4);
   
INSERT INTO Issue (issue_type, summary, issue_description, assignee_id, state, priority, due_date, sprint_id, board_id)
VALUES 
  ('Bug', 'Error in login page', 'The login page is returning a 500 error', 3, 'Open', 'High', '2023-01-15', 1, 2),
  ('Task', 'Implement user registration', 'Add user registration feature to the system', 5, 'In Progress', 'Medium', '2023-01-28', 1, 2),
  ('Task', 'Refactor database schema', 'The database schema needs to be updated to improve performance', 3, 'Open', 'High', '2023-02-11', 4, 5),
  ('Bug', 'Incorrect product price', 'The price of Product X is incorrect on the website', 6, 'In Progress', 'Medium', '2023-01-28', 2, 6),
  ('Task', 'Add search functionality', 'Implement search feature on the website', 4, 'Open', 'Low', '2023-02-11', 4, 6),
  ('Bug', 'Cannot upload profile picture', 'Users are unable to upload their profile pictures', 7, 'Resolved', 'Low', '2023-01-14', 3, 4),
  ('Task', 'Implement checkout process', 'Add checkout process for users to purchase products', 8, 'In Progress', 'High', '2023-02-11', 5, 7),
  ('Bug', 'Incorrect order total', 'The order total is not calculating correctly', 9, 'Open', 'Medium', '2023-01-28', 4, 5),
  ('Task', 'Update website design', 'Redesign the website to improve user experience', 2, 'Resolved', 'Low', '2023-01-14', 1, 1),
  ('Task', 'Write user manual', 'Create a user manual for the system', 10, 'Open', 'Low', '2023-02-11', 3, 3);

INSERT INTO Comment (comment_text, user_id, issue_id)
VALUES 
  ('I can look into this issue', 2, 1),
  ('This is a high priority issue, please work on it immediately', 1, 1),
  ('I have started working on this task', 5, 2),
  ('I have finished working on this task and it is now ready for testing', 5, 2),
  ('I have fixed the bug', 3, 4),
  ('This issue has been resolved', 7, 6),
  ('I am currently working on this task', 4, 7),
  ('I have completed this task', 4, 7),
  ('I am looking into this issue', 10, 8),
  ('This is a medium priority issue', 9, 8);
   

INSERT INTO Attachment (filename, file_path, user_id, issue_id)
VALUES ('screenshot1.png', '/attachments/1/screenshot1.png', 3, 1),
	('screenshot2.png', '/attachments/1/screenshot2.png', 3, 1),
	('error.log', '/attachments/2/error.log', 3, 1),
	('user_registration.png', '/attachments/3/user_registration.png', 5, 2),
	('database_schema.png', '/attachments/4/database_schema.png', 5, 2),
	('user_story.pdf', '/attachments/5/user_story.pdf', 7, 3),
	('test_cases.xlsx', '/attachments/6/test_cases.xlsx', 8, 4),
	('bug_report.docx', '/attachments/7/bug_report.docx', 10, 5),
	('proposal.pdf', '/attachments/8/proposal.pdf', 10, 5),
	('design_specification.docx', '/attachments/9/design_specification.docx', 10, 5);
   


show tables;
SELECT * FROM `Role`;
SELECT * FROM `User`;
SELECT * FROM Project;
SELECT * FROM Sprint;
SELECT * FROM Board;
SELECT * FROM Issue;
SELECT * FROM `Comment`;
SELECT * FROM Attachment;
