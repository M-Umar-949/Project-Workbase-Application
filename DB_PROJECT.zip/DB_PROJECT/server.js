
const express = require('express');
const mysql = require('mysql');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');

const session = require('express-session');

app.use(session({
  secret: 'your_secret_key',  // choose a secret key to sign the session ID cookie
  resave: false,              // don't save session if unmodified
  saveUninitialized: false,   // don't create session until something stored
  cookie: { secure: false }   // in production, set this to true
}));

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));


// Create a MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Test@123',
  database: 'pwb',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});



// Set the view engine to EJS

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'Login_Page.html'));
});


// Set the views directory
app.set('views', path.join(__dirname, 'views'));

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.get('/Sign_up.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'Sign_up.html'));
});

app.get('/Login_Page.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'Login_Page.html'));
});

app.get('/team', (req, res) => {
  res.render('team')
});

app.get('/project', (req, res, next) => {
  if (req.session.role_id !== 1) {
    res.redirect('/add_project');
    return;
  }
  next();
}, (req, res) => {
  // Retrieve the project data from the MySQL table
  pool.query('SELECT * FROM Project', (error, results) => {
    if (error) {
      console.error('Error retrieving projects:', error);
      return res.status(500).send('Error retrieving projects');
    }

    const projects = results;

    // Render the project page and pass the projects data to the view
    res.render('project', { projects });
  });
});




app.get('/add_project', (req, res) => {
  // Retrieve the project data from the MySQL table
  pool.query('SELECT * FROM Project', (error, results) => {
    if (error) {
      console.error('Error retrieving projects:', error);
      return res.status(500).send('Error retrieving projects');
    }

    const projects = results;

    // Render the add_project page and pass the projects data to the view
    res.render('add_project', { projects });
  });
});


app.get('/issue', (req, res) => {
  // Retrieve the project data from the MySQL table
  pool.query('SELECT * FROM Issue', (error, issueResults) => {
    if (error) {
      console.error('Error retrieving issues:', error);
      return res.status(500).send('Error retrieving issues');
    }

    // Retrieve the comment data from the MySQL table
    pool.query('SELECT * FROM Comment', (error, commentResults) => {
      if (error) {
        console.error('Error retrieving comments:', error);
        return res.status(500).send('Error retrieving comments');
      }

      // Combine the issues and comments data
      const issues = issueResults.map(issue => {
        return {
          issue_id: issue.issue_id,
          issue_description: issue.issue_description,
          issue_type : issue.issue_type,
          assignee_id: issue.assignee_id,
          summary:issue.summary,
          priority: issue.priority,
          state: issue.state,
          comments: commentResults.filter(comment => comment.issue_id === issue.issue_id)
        };
      });

      // Render the project page and pass the projects data to the view
      res.render('issue', {issues});
    });
  });
});

app.post('/insert-user', (req, res) => {
  const {user_name, email, password, role_id } = req.body;

  const query = `INSERT INTO User (user_name, email, password, role_id )
  VALUES (?, ?, ?, ?)`;

  const values = [user_name, email, password, role_id];

  pool.query(query, values, (error, results, fields) => {
    if (error) {
      console.error(error);
      res.status(500).send('Error inserting customer');
    } else {
      res.redirect('Login_Page.html');
    }
    
  });
});




app.post('/check-user', (req, res) => {
  const { user_name, password } = req.body;

  const query = `SELECT * FROM User WHERE user_name = ? AND password = ?`;
  const values = [user_name, password];
  pool.query(query, values, (error, results) => {
    if (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
      return;
    }

    if (results.length === 0) {
      res.status(401).send('Invalid username or password');
      return;
    }

    const user = results[0];
    req.session.role_id = user.role_id;  // store the role_id in the session
    if (user.role_id === 1) {
      res.redirect('/project');
    } else {
      res.redirect('/add_project');
    }
  });
});


app.get('/board', (req, res) => {app.get('/project', (req, res, next) => {
  if (req.session.role_id !== 1) {
    res.redirect('/add_project');
    return;
  }
  next();
});

  // Retrieve the project data from the MySQL table
  pool.query('SELECT * FROM Project', (error, results) => {
    if (error) {
      console.error('Error retrieving projects:', error);
      return res.status(500).send('Error retrieving projects');
    }

    const projects = results;
    const toDoProjects = projects.filter(project => project.status === 'To Do');
    const inProgressProjects = projects.filter(project => project.status === 'In Progress');
    const finishedProjects = projects.filter(project => project.status === 'Done');

    // Render the board page and pass the projects data to the view
    res.render('board', {toDoProjects, inProgressProjects, finishedProjects});
  });
});

//add satus here as well
app.post('/submit_project', (req, res) => {
    const { project_name, project_description, start_date, end_date, team_lead_id } = req.body;
    const statusInput = req.body.statusInput;

    let status = '';
    const today = new Date();
    const projectStartDate = new Date(start_date);
    const projectEndDate = new Date(end_date);

    if (projectEndDate < today) {
        status = 'Done';
    } else if (projectStartDate > today) {
        status = 'To Do';
    } else {
        status = 'In Progress';
    }

    const query = `INSERT INTO Project (project_name, project_description, start_date, end_date, team_lead_id, status)
                 VALUES (?, ?, ?, ?, ?, ?)`;

    const values = [project_name, project_description, start_date, end_date, team_lead_id, status];

    pool.query(query, values, (error, results, fields) => {
        if (error) {
            console.error(error);
            res.status(500).send('Error inserting project');
        } else {
            res.send('Project inserted successfully');
        }
    });
});


app.get('/report', (req, res) => {
  // Define a SQL query to fetch the necessary data from the Issue table
  const query = `
    SELECT assignee_id, state, priority, COUNT(*) as count
    FROM Issue
    GROUP BY assignee_id, state, priority
  `;

  // Execute the SQL query to fetch the data from the Issue table
  res.render('report')
    
});

app.delete('/projects/:id', (req, res) => {
  const id = req.params.id;

  // First, delete associated rows from the `board` table
  const deleteBoardQuery = 'DELETE FROM Board WHERE project_id = ?';
  pool.query(deleteBoardQuery, id, (error, result) => {
    if (error) {
      console.error(error);
      res.status(500).send('Server error');
      return;
    }

    // Then, delete the row from the `Project` table
    const deleteProjectQuery = 'DELETE FROM Project WHERE project_id = ?';
    pool.query(deleteProjectQuery, id, (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send('Server error');
      } else {
        res.status(200).send('Project deleted');
      }
    });
  });
});


// Handle errors for unhandled routes
app.use((req, res) => {
  res.status(404).send('Page not found');
});


var server = app.listen(8081, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at http://%s:%s", host,port)
});